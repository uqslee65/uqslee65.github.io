# zigan-simulation

Browser-based agent simulation of the **Dufwenberg, Lindqvist & Moore (2005)** asset-market
bubble experiment ("Bubbles and Experience", AER 95(5)), extracted from the `phd-finance-student`
website so it can run standalone and be embedded by the site from a single source of truth.

## Model (single asset per session)

Heterogeneous CRRA agents trade **one** finite-lived asset across four consecutive markets
(rounds). There is **no** simultaneous multi-asset portfolio. Rounds 1–3 keep the same traders
(who accumulate experience); at the replacement round a fraction of experienced traders is
swapped for inexperienced newcomers, optionally swapping the asset type.

Calibrated (Plan I) to the reference implementation at `assets.m0nius.com`. Reproduces the four
conclusions:

1. Positive mispricing (bubble) that **decreases with experience** (rounds 1 → 3).
2. A **minority experienced + majority inexperienced** population does **not** generate large bubbles.
3. Mispricing **depends on the asset type**.
4. Experience **does not transfer across (uncorrelated) assets**.

## Usage

Standalone:

```bash
npm install
npm run dev      # standalone app
npm run build    # production bundle
npm test         # engine + replication unit tests (vitest)
```

As a library (the website does this via a Vite alias to `src/index.ts`):

```ts
import { BubbleSimulator } from 'zigan-simulation';
```

## Layout

- `src/lib/sim/` — engine, metrics, assets, types, LLM client/prompts/engine
- `src/components/simulator/` — React UI (control bar, figures, config, replay, …)
- `src/components/BubbleSimulator.tsx` — top-level component
- `src/index.ts` — public package entry
