import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Standalone dev/build for the simulator. The website consumes the package source
// directly (via a Vite alias), so this config only drives the standalone app.
export default defineConfig({
  plugins: [react()],
  resolve: { dedupe: ['react', 'react-dom'] },
});
