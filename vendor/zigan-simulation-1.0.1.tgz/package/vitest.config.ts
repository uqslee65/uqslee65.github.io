import { defineConfig } from 'vitest/config';

// Engine/metrics/replication tests are pure logic — no DOM needed.
export default defineConfig({
  test: {
    environment: 'node',
    include: ['src/**/*.{test,spec}.{ts,tsx}'],
  },
});
