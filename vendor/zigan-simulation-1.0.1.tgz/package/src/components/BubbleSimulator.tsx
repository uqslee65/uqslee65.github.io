import { SimulatorProvider, useSimulator } from './simulator/SimulatorProvider';
import { ControlBar } from './simulator/ControlBar';
import { PlanSelector } from './simulator/PlanSelector';
import { SimulatorLayout } from './simulator/SimulatorLayout';
import { ErrorBoundary } from './simulator/ErrorBoundary';
import { ErrorToast } from './simulator/ErrorToast';
import { WalkthroughProvider } from './walkthrough/WalkthroughProvider';
import { WalkthroughOverlay, WalkthroughLaunchButton } from './walkthrough/WalkthroughOverlay';

function SimulatorInner() {
  const { reset, error, clearError } = useSimulator();
  return (
    <ErrorBoundary onReset={reset}>
      <WalkthroughProvider>
        <div style={{ width: '100%', maxWidth: '1400px', margin: '0 auto', padding: '0 1rem' }}>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '0.5rem' }}>
            <WalkthroughLaunchButton />
          </div>
          <ControlBar />
          <PlanSelector />
          <SimulatorLayout />
        </div>
        <WalkthroughOverlay />
      </WalkthroughProvider>
      {error && <ErrorToast message={error} onDismiss={clearError} />}
    </ErrorBoundary>
  );
}

export default function BubbleSimulator() {
  return (
    <SimulatorProvider>
      <SimulatorInner />
    </SimulatorProvider>
  );
}
