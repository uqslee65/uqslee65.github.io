import { DLM_TABLE2, M0NIUS_BATCH, evaluateClaims, type PerRound } from './referenceData';

const cell: React.CSSProperties = { padding: '0.25rem 0.5rem', textAlign: 'right', fontVariantNumeric: 'tabular-nums' };
const head: React.CSSProperties = { ...cell, fontWeight: 700, color: 'var(--fg-3)', fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.04em' };

function num(n: number | undefined, d = 2) { return n === undefined ? '—' : n.toFixed(d); }

export function ComparisonPanel({ ours }: { ours: PerRound[] | undefined }) {
  const claims = ours ? evaluateClaims(ours) : [];
  return (
    <div data-testid="comparison-panel" style={{ marginTop: '0.5rem' }}>
      {/* Haessel R^2 */}
      <Measure3
        title="Haessel R²"
        dp={3}
        rows={[1, 2, 3, 4].map((r) => ({
          round: r,
          paper: DLM_TABLE2[r as 1].haesselR2,
          monius: M0NIUS_BATCH[r as 1].haesselR2,
          ours: ours?.[r - 1]?.haesselR2,
        }))}
      />
      {/* Amplitude */}
      <Measure3
        title="Amplitude (÷FV₁)"
        dp={3}
        rows={[1, 2, 3, 4].map((r) => ({
          round: r,
          paper: DLM_TABLE2[r as 1].amplitude,
          monius: M0NIUS_BATCH[r as 1].amplitude,
          ours: ours?.[r - 1]?.amplitude,
        }))}
      />
      <p style={{ fontSize: '0.66rem', color: 'var(--fg-3)', margin: '0 0 0.6rem' }}>
        "Ours" is the mean of 10 seeded sessions (as DLM Table 2 and the m0nius batch report).
        Deviations use different normalizations per source (DLM ÷24 shares; m0nius per-tick mean),
        so R² and amplitude — one definition everywhere — carry the numeric proof.
      </p>

      <div data-testid="claim-list">
        {claims.map((c) => (
          <div key={c.id} style={{ display: 'flex', gap: '0.5rem', alignItems: 'baseline', margin: '0.25rem 0', fontSize: '0.74rem' }}>
            <span style={{ color: c.holds ? '#16a34a' : '#dc2626', fontWeight: 800 }}>{c.holds ? '✓' : '✗'}</span>
            <span>
              <strong>{c.label}</strong>
              <span style={{ color: 'var(--fg-3)' }}> — {c.detail}</span>
            </span>
          </div>
        ))}
        {!ours && <p style={{ fontSize: '0.74rem', color: 'var(--fg-3)' }}>Running…</p>}
      </div>
    </div>
  );
}

interface Row3 { round: number; paper: number; monius: number; ours: number | undefined; }

function Measure3({ title, rows, dp }: { title: string; rows: Row3[]; dp: number }) {
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem', marginBottom: '0.6rem' }}>
      <thead>
        <tr>
          <th style={{ ...head, textAlign: 'left' }}>{title}</th>
          <th style={head}>DLM ’05</th>
          <th style={head}>m0nius</th>
          <th style={{ ...head, color: 'var(--accent)' }}>Ours</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.round} style={{ borderTop: '1px solid var(--border)' }}>
            <td style={{ ...cell, textAlign: 'left', fontWeight: 600 }}>R{r.round}</td>
            <td style={cell}>{num(r.paper, dp)}</td>
            <td style={cell}>{num(r.monius, dp)}</td>
            <td style={{ ...cell, color: 'var(--accent)', fontWeight: 700 }}>{num(r.ours, dp)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

/** Cross-plan: round-1 vs round-3 mean |P-FV| per plan. */
export function CrossPlanPanel({ plans }: { plans: { label: string; output: PerRound[] | undefined }[] }) {
  return (
    <table data-testid="cross-plan-panel" style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem' }}>
      <thead>
        <tr>
          <th style={{ ...head, textAlign: 'left' }}>Plan</th>
          <th style={head}>R1 mean |P−FV|</th>
          <th style={head}>R3 mean |P−FV|</th>
          <th style={head}>R1 → R3</th>
        </tr>
      </thead>
      <tbody>
        {plans.map((p) => {
          const r1 = p.output?.[0]?.meanDev, r3 = p.output?.[2]?.meanDev;
          const down = r1 !== undefined && r3 !== undefined && r3 < r1;
          return (
            <tr key={p.label} style={{ borderTop: '1px solid var(--border)' }}>
              <td style={{ ...cell, textAlign: 'left', fontWeight: 600 }}>{p.label}</td>
              <td style={cell}>{num(r1)}</td>
              <td style={cell}>{num(r3)}</td>
              <td style={{ ...cell, color: down ? '#16a34a' : 'var(--fg-3)', fontWeight: 700 }}>
                {r1 === undefined ? '—' : down ? '↓ shrinks' : 'n/a'}
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
