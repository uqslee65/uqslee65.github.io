import { useEffect, useState } from 'react';

interface Rect { top: number; left: number; width: number; height: number; }

/**
 * Dims the page and cuts a glowing "spotlight" hole around the element matching `selector`.
 * Tracks the element's position (it may animate/resize) on an interval. If the selector
 * matches nothing, the whole page is gently dimmed with no cutout.
 */
export function Spotlight({ selector }: { selector?: string }) {
  const [rect, setRect] = useState<Rect | null>(null);

  useEffect(() => {
    if (!selector) { setRect(null); return; }
    let raf = 0;
    const tick = () => {
      const el = document.querySelector(selector) as HTMLElement | null;
      if (el) {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) {
          setRect({ top: r.top - 8, left: r.left - 8, width: r.width + 16, height: r.height + 16 });
        }
      } else {
        setRect(null);
      }
      raf = window.setTimeout(tick, 250) as unknown as number;
    };
    tick();
    return () => window.clearTimeout(raf);
  }, [selector]);

  if (!rect) {
    return (
      <div
        aria-hidden
        style={{ position: 'fixed', inset: 0, background: 'rgba(15,18,28,0.35)', zIndex: 1400, pointerEvents: 'none' }}
      />
    );
  }

  return (
    <div
      aria-hidden
      data-testid="walkthrough-spotlight"
      style={{
        position: 'fixed',
        top: rect.top, left: rect.left, width: rect.width, height: rect.height,
        borderRadius: 10,
        // The huge spread box-shadow dims everything EXCEPT this hole.
        boxShadow: '0 0 0 9999px rgba(15,18,28,0.55)',
        outline: '2px solid var(--accent)',
        animation: 'wt-glow 1.6s ease-in-out infinite',
        zIndex: 1400,
        pointerEvents: 'none',
      }}
    >
      <style>{`
        @keyframes wt-glow {
          0%,100% { box-shadow: 0 0 0 9999px rgba(15,18,28,0.55), 0 0 0 0 color-mix(in srgb, var(--accent) 70%, transparent); }
          50%     { box-shadow: 0 0 0 9999px rgba(15,18,28,0.55), 0 0 18px 6px color-mix(in srgb, var(--accent) 55%, transparent); }
        }
      `}</style>
    </div>
  );
}
