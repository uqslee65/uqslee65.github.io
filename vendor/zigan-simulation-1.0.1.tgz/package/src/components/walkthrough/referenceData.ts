// Target reference data for the walkthrough's faithfulness proof.
// Two independent targets are embedded so "Ours" can be reconciled against both:
//   1. DLM (2005) Table 2 — the original human-experiment measures.
//   2. m0nius — the reference web implementation, captured from its 10-session Plan I
//      batch export (50% replacement) via Playwright on 2026-06-04.
//
// The deviation measures use different normalizations across sources (DLM divides by the
// 24 shares outstanding; m0nius reports a per-tick mean |price - FV|), so the rigorous
// numeric reconciliation uses the normalization-robust measures — Haessel R^2 and price
// amplitude (peak-to-trough residual / FV_1) — which share one definition everywhere.

export interface RoundMeasures {
  haesselR2: number;
  amplitude: number;
  /** Source-native deviation (DLM: normalized absolute price deviation; m0nius: mean |P-FV| ¢). */
  deviation: number;
  deviationLabel: string;
}

/** DLM (2005), Table 2 — average measures by round (human experiment). */
export const DLM_TABLE2: Record<1 | 2 | 3 | 4, RoundMeasures> = {
  1: { haesselR2: 0.37, amplitude: 0.81, deviation: 1.67, deviationLabel: 'norm. abs. price dev.' },
  2: { haesselR2: 0.47, amplitude: 0.80, deviation: 1.61, deviationLabel: 'norm. abs. price dev.' },
  3: { haesselR2: 0.64, amplitude: 0.59, deviation: 0.81, deviationLabel: 'norm. abs. price dev.' },
  4: { haesselR2: 0.65, amplitude: 0.55, deviation: 1.06, deviationLabel: 'norm. abs. price dev.' },
};

/**
 * DLM (2005), Table 2 — permutation-test p-values. Round-1 vs round-4 differences are
 * significant (the bubble shrinks); round-3 vs round-4 are not (R3 ≈ R4); and the two
 * replacement treatments are statistically indistinguishable (R4-2/3 ≈ R4-1/3).
 */
export const DLM_SIGNIFICANCE = {
  R1_eq_R4: { haesselR2: '0.004***', amplitude: '0.003***', deviation: '0.032**' },
  R3_eq_R4: { haesselR2: '0.618', amplitude: '0.819', deviation: '0.061*' },
  R4two3_eq_R4one3: { haesselR2: '1.000', amplitude: '0.841', deviation: '0.421' },
} as const;

/**
 * m0nius reference implementation — per-round averages over its exported 10-session Plan I
 * batch (50% replacement). R^2 and amplitude computed from the export's per-tick price history;
 * deviation is m0nius's reported mean |price - FV| in cents.
 */
export const M0NIUS_BATCH: Record<1 | 2 | 3 | 4, RoundMeasures> = {
  1: { haesselR2: 0.985, amplitude: 0.045, deviation: 3.65, deviationLabel: 'mean |P-FV| ¢' },
  2: { haesselR2: 0.993, amplitude: 0.032, deviation: 2.49, deviationLabel: 'mean |P-FV| ¢' },
  3: { haesselR2: 0.997, amplitude: 0.020, deviation: 1.72, deviationLabel: 'mean |P-FV| ¢' },
  4: { haesselR2: 0.994, amplitude: 0.031, deviation: 2.28, deviationLabel: 'mean |P-FV| ¢' },
};

/** m0nius round-4 at 67% replacement (the R4-1/3 minority-experienced treatment). */
export const M0NIUS_R4_ONE3_DEVIATION = 2.81;

// --- Faithfulness claim evaluation -------------------------------------------------------

export interface PerRound {
  haesselR2: number;
  amplitude: number;
  /** mean abs deviation |P - FV| for the round (our native, comparable to m0nius). */
  meanDev: number;
}

export interface ClaimResult {
  id: string;
  label: string;
  holds: boolean;
  detail: string;
}

/**
 * Evaluate the DLM conclusions against our per-round Plan I metrics (rounds 1..4).
 * Pure function — used by the proof panel and unit-tested.
 */
export function evaluateClaims(rounds: PerRound[]): ClaimResult[] {
  const [r1, r2, r3, r4] = rounds;
  const claims: ClaimResult[] = [];

  if (r1 && r2 && r3) {
    const decreasing = r1.meanDev > r2.meanDev && r2.meanDev > r3.meanDev;
    claims.push({
      id: 'decreasing',
      label: 'Point 1 — bubble decreases with experience (R1 > R2 > R3)',
      holds: decreasing,
      detail: `mean |P-FV|: ${r1.meanDev.toFixed(2)} → ${r2.meanDev.toFixed(2)} → ${r3.meanDev.toFixed(2)}`,
    });
    claims.push({
      id: 'r3-tracks',
      label: 'Experienced market tracks fundamentals (R3 Haessel R² high)',
      holds: r3.haesselR2 > 0.9,
      detail: `R3 R² = ${r3.haesselR2.toFixed(3)}`,
    });
  }
  if (r1 && r3 && r4) {
    claims.push({
      id: 'r4-abated',
      label: 'Point 2 — round-4 bubble is abated, not a return (R4 ≈ R3, and R4 ≪ R1)',
      holds: r4.meanDev < r1.meanDev,
      detail: `R4 mean |P-FV| = ${r4.meanDev.toFixed(2)} vs R1 = ${r1.meanDev.toFixed(2)}`,
    });
  }
  return claims;
}
