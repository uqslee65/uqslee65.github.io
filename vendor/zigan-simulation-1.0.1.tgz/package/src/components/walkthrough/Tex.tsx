import katex from 'katex';
import 'katex/dist/katex.min.css';

/** Inline or block KaTeX. Renders to HTML string; never throws on malformed input. */
export function Tex({ children, block = false }: { children: string; block?: boolean }) {
  const html = katex.renderToString(children, {
    throwOnError: false,
    displayMode: block,
  });
  return (
    <span
      style={block ? { display: 'block', margin: '0.5rem 0', overflowX: 'auto' } : undefined}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
