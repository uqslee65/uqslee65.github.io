import { describe, it, expect } from 'vitest';
import { DLM_TABLE2, M0NIUS_BATCH, evaluateClaims, type PerRound } from '../referenceData';

describe('walkthrough reference data', () => {
  it('DLM Table 2 and m0nius both show decreasing amplitude R1 -> R3', () => {
    expect(DLM_TABLE2[1].amplitude).toBeGreaterThan(DLM_TABLE2[3].amplitude);
    expect(M0NIUS_BATCH[1].amplitude).toBeGreaterThan(M0NIUS_BATCH[3].amplitude);
  });

  it('both targets show rising Haessel R^2 with experience (R1 < R3)', () => {
    expect(DLM_TABLE2[1].haesselR2).toBeLessThan(DLM_TABLE2[3].haesselR2);
    expect(M0NIUS_BATCH[1].haesselR2).toBeLessThan(M0NIUS_BATCH[3].haesselR2);
  });
});

describe('evaluateClaims', () => {
  const faithful: PerRound[] = [
    { haesselR2: 0.97, amplitude: 0.10, meanDev: 3.8 },
    { haesselR2: 0.97, amplitude: 0.09, meanDev: 2.7 },
    { haesselR2: 0.99, amplitude: 0.06, meanDev: 1.9 },
    { haesselR2: 0.98, amplitude: 0.09, meanDev: 2.7 },
  ];

  it('passes all claims for a faithful (decreasing, abated-R4) run', () => {
    const claims = evaluateClaims(faithful);
    expect(claims.length).toBeGreaterThanOrEqual(3);
    expect(claims.every(c => c.holds)).toBe(true);
  });

  it('fails the decreasing claim when R1 < R2', () => {
    const bad = [...faithful];
    bad[0] = { ...bad[0], meanDev: 1.0 }; // R1 lower than R2 -> not decreasing
    const claims = evaluateClaims(bad);
    expect(claims.find(c => c.id === 'decreasing')!.holds).toBe(false);
  });

  it('fails the R4-abated claim when R4 re-bubbles above R1', () => {
    const bad = [...faithful];
    bad[3] = { ...bad[3], meanDev: 9.9 }; // R4 worse than R1
    const claims = evaluateClaims(bad);
    expect(claims.find(c => c.id === 'r4-abated')!.holds).toBe(false);
  });
});
