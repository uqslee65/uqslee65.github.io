import { createContext, useContext, useState, useRef, useEffect, useCallback, type ReactNode } from 'react';
import { useSimulator } from '../simulator/SimulatorProvider';
import { runSession } from '../../lib/sim/engine';
import { computeMetrics } from '../../lib/sim/metrics';
import { DLM_DEFAULTS, type SimConfig, type PlanType } from '../../lib/sim/types';
import { STAGES, type Stage } from './stages';
import type { PerRound } from './referenceData';

const WALK_SEED = 42;
const DEEPSEEK = {
  provider: 'deepseek' as const,
  apiFormat: 'openai-compat' as const,
  baseUrl: 'https://api.deepseek.com',
  model: 'deepseek-v4-flash',
};

function computePerRound(periods: { round: number; meanPrice: number; fv: number }[]): PerRound[] {
  const byRound: Record<number, { meanPrice: number; fv: number }[]> = { 1: [], 2: [], 3: [], 4: [] };
  for (const p of periods) (byRound[p.round] ??= []).push(p);
  return [1, 2, 3, 4].map(r => {
    const ps = byRound[r] ?? [];
    const m = computeMetrics(ps as { meanPrice: number; fv: number; trades: unknown[] }[], DLM_DEFAULTS.fv1, 30);
    const meanDev = ps.reduce((s, p) => s + Math.abs(p.meanPrice - p.fv), 0) / (ps.length || 1);
    return { haesselR2: m.haesselR2, amplitude: m.amplitude, meanDev };
  });
}

interface WalkthroughValue {
  active: boolean;
  start: () => void;
  exit: () => void;
  stageIndex: number;
  stage: Stage;
  total: number;
  next: () => void;
  prev: () => void;
  canAdvance: boolean;
  blockReason: string | null;
  busy: boolean;
  outputs: Record<string, PerRound[]>;
  // LLM-stage inputs
  apiKey: string;
  setApiKey: (k: string) => void;
  runCurrentLLM: () => void;
}

const Ctx = createContext<WalkthroughValue | null>(null);

export function useWalkthrough(): WalkthroughValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useWalkthrough must be used inside WalkthroughProvider');
  return v;
}

export function WalkthroughProvider({ children }: { children: ReactNode }) {
  const sim = useSimulator();
  const [active, setActive] = useState(false);
  const [stageIndex, setStageIndex] = useState(0);
  const [outputs, setOutputs] = useState<Record<string, PerRound[]>>({});
  const [apiKey, setApiKey] = useState('');
  const [busy, setBusy] = useState(false);
  const [pending, setPending] = useState<{ id: string; kind: 'plan-i' | 'llm' } | null>(null);
  const ranRef = useRef<Set<string>>(new Set());
  const planSetRef = useRef<Set<string>>(new Set());
  const llmWaitRef = useRef<string | null>(null);

  const stage = STAGES[stageIndex];

  const buildConfig = useCallback((s: Stage): SimConfig => {
    const base: SimConfig = { ...DLM_DEFAULTS, seed: WALK_SEED, plan: s.plan ?? 'plan-i', ...s.config };
    if (s.kind === 'run-llm') {
      base.llm = { ...DEEPSEEK, apiKey, maxConcurrent: 1000 };
      // Bounded LLM run for automated tests (set window.__WT_LLM_SMALL__): proves the live
      // gate + a real API call without the cost/time of a near-full 800-call run.
      if (typeof window !== 'undefined' && (window as { __WT_LLM_SMALL__?: boolean }).__WT_LLM_SMALL__) {
        base.nAgents = 4; base.nRounds = 1; base.nPeriods = 1; base.ticksPerPeriod = 4;
      }
    }
    return base;
  }, [apiKey]);

  // Entering a deterministic Plan I stage: apply its config, then queue a run. The actual
  // run fires in the effect below once sim.config reflects the change (avoids stale closures).
  useEffect(() => {
    if (!active) return;
    const s = STAGES[stageIndex];
    if (s.kind === 'run-plan-i' && !ranRef.current.has(s.id)) {
      ranRef.current.add(s.id);
      sim.setConfig(buildConfig(s));
      setPending({ id: s.id, kind: 'plan-i' });
    }
    // Switch to the LLM plan on ENTRY so the later setConfig (which carries the API key)
    // does not trigger the plan-change branch that discards `llm`. The run is still manual.
    if (s.kind === 'run-llm' && !planSetRef.current.has(s.id)) {
      planSetRef.current.add(s.id);
      sim.setConfig({ plan: s.plan });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, stageIndex]);

  // Fire a queued run once the simulator's config matches what the stage asked for.
  useEffect(() => {
    if (!pending) return;
    const s = STAGES.find(x => x.id === pending.id);
    if (!s) { setPending(null); return; }
    const want = buildConfig(s);
    const ready =
      sim.config.plan === want.plan &&
      sim.config.seed === want.seed &&
      sim.config.treatment === want.treatment &&
      sim.config.assetClass === want.assetClass &&
      (pending.kind !== 'llm' || sim.config.llm?.apiKey === want.llm?.apiKey);
    if (!ready) return;

    if (pending.kind === 'plan-i') {
      sim.runPlanI(); // single seeded run for the on-screen chart
      // Proof numbers are averaged over N seeded sessions — matching how DLM (Table 2) and the
      // m0nius batch report (10-session averages), and removing single-session variance.
      const N = 10;
      const acc = [0, 1, 2, 3].map(() => ({ haesselR2: 0, amplitude: 0, meanDev: 0 }));
      for (let i = 0; i < N; i++) {
        const r = runSession({ ...want, seed: want.seed + i * 1000 }, i);
        computePerRound(r.periods).forEach((pr, j) => {
          acc[j].haesselR2 += pr.haesselR2; acc[j].amplitude += pr.amplitude; acc[j].meanDev += pr.meanDev;
        });
      }
      const avg = acc.map(a => ({ haesselR2: a.haesselR2 / N, amplitude: a.amplitude / N, meanDev: a.meanDev / N }));
      setOutputs(prev => ({ ...prev, [s.id]: avg }));
      setPending(null);
    } else {
      llmWaitRef.current = s.id;
      sim.runLLM();
      setPending(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pending, sim.config]);

  // When a live LLM run finishes, cache its per-round metrics for the waiting stage.
  useEffect(() => {
    const waitingId = llmWaitRef.current;
    if (!waitingId) return;
    if (!sim.llmRunning && sim.llmSession && sim.llmSession.periods.length > 0) {
      setOutputs(prev => ({ ...prev, [waitingId]: computePerRound(sim.llmSession!.periods) }));
      llmWaitRef.current = null;
      setBusy(false);
    }
  }, [sim.llmRunning, sim.llmSession]);

  const runCurrentLLM = useCallback(() => {
    const s = STAGES[stageIndex];
    if (s.kind !== 'run-llm' || !apiKey.trim()) return;
    ranRef.current.add(s.id);
    setBusy(true);
    sim.setConfig(buildConfig(s));
    setPending({ id: s.id, kind: 'llm' });
  }, [stageIndex, apiKey, buildConfig, sim]);

  // Gate: can the user advance from this stage?
  let canAdvance = true;
  let blockReason: string | null = null;
  if (active) {
    if (stage.kind === 'run-plan-i' && !outputs[stage.id]) {
      canAdvance = false; blockReason = 'Running the simulation…';
    } else if (stage.kind === 'run-llm') {
      if (!apiKey.trim()) { canAdvance = false; blockReason = 'Enter a DeepSeek API key to run this stage.'; }
      else if (sim.llmRunning || busy) { canAdvance = false; blockReason = 'Live LLM run in progress…'; }
      else if (!outputs[stage.id]) { canAdvance = false; blockReason = 'Run the live LLM simulation to continue.'; }
    }
  }

  const start = useCallback(() => { setActive(true); setStageIndex(0); }, []);
  const exit = useCallback(() => { setActive(false); sim.stop(); }, [sim]);
  const next = useCallback(() => {
    if (!canAdvance) return;
    setStageIndex(i => Math.min(i + 1, STAGES.length - 1));
  }, [canAdvance]);
  const prev = useCallback(() => setStageIndex(i => Math.max(0, i - 1)), []);

  const value: WalkthroughValue = {
    active, start, exit,
    stageIndex, stage, total: STAGES.length,
    next, prev, canAdvance, blockReason, busy,
    outputs,
    apiKey, setApiKey, runCurrentLLM,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export type { Stage } from './stages';
export type { PlanType };
