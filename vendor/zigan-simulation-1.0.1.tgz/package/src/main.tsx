import React from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';
import { BubbleSimulator } from './index';

const root = document.getElementById('root');
if (root) {
  createRoot(root).render(
    <React.StrictMode>
      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '1.5rem 1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: '0.5rem' }}>
          DLM (2005) — Bubbles and Experience
        </h1>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-dim)', marginBottom: '1.5rem', maxWidth: 640 }}>
          Interactive replication of Dufwenberg, Lindqvist &amp; Moore (AER 2005): heterogeneous
          CRRA agents trade a single finite-lived asset across four consecutive rounds with
          experience-indexed belief updating and replacement-round novice entry.
        </p>
        <BubbleSimulator />
      </div>
    </React.StrictMode>,
  );
}
