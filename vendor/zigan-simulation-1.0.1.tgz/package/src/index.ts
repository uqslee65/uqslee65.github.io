// Public entry point for the zigan-simulation package.
// The website (and any other consumer) imports the simulator from here.

export { default as BubbleSimulator } from './components/BubbleSimulator';

export { testConnection } from './lib/sim/llm-client';

export type {
  LLMConfig,
  LLMProvider,
  ApiFormat,
  SimConfig,
  PlanType,
  Plan,
  AssetClass,
  RiskPreference,
} from './lib/sim/types';
