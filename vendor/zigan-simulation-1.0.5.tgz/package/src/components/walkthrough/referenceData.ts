// Target reference data for the walkthrough's honest reconciliation.
//
// Two reference sources are embedded; the chosen faithfulness *target* is the m0nius
// reference implementation (our engine replicates m0nius's belief model and config). The
// DLM (2005) paper is shown for context.
//
//   1. DLM (2005) Table 2 — the original human-experiment per-round measures (published).
//   2. m0nius — the reference web implementation, re-verified live via Playwright on
//      2026-06-05 with the SAME config as ours (N=10, R=4, α0=1, σ0=5, ω0=0.6, …).
//
// IMPORTANT provenance note (corrected 2026-06-05): m0nius reports per-round only the mean
// absolute deviation |P−FV| (¢) and turnover; its Haessel R² and amplitude are reported
// ONLY pooled across the whole session, not per round. An earlier version of this file
// embedded per-round m0nius R²/amplitude — those were our own computeMetrics() applied to
// m0nius's price export (with a since-fixed denominator bug), not numbers m0nius reports.
// They have been removed. The honest per-round m0nius comparison is mean |P−FV|.
//
// Magnitude caveat: neither this model nor m0nius reproduces the DLM human bubble *magnitude*
// (R1 amplitude ≈ 0.81 in the paper vs ≈ 0.05 here). Both replicate the experience-driven
// *direction* (mispricing falls R1→R3, R4 abated), which is what this walkthrough verifies.

export interface RoundMeasures {
  haesselR2: number;
  amplitude: number;
  /** Source-native deviation (DLM: normalized absolute price deviation; m0nius: mean |P-FV| ¢). */
  deviation: number;
  deviationLabel: string;
}

/** DLM (2005), Table 2 — average measures by round (human experiment). */
export const DLM_TABLE2: Record<1 | 2 | 3 | 4, RoundMeasures> = {
  1: { haesselR2: 0.37, amplitude: 0.81, deviation: 1.67, deviationLabel: 'norm. abs. price dev.' },
  2: { haesselR2: 0.47, amplitude: 0.80, deviation: 1.61, deviationLabel: 'norm. abs. price dev.' },
  3: { haesselR2: 0.64, amplitude: 0.59, deviation: 0.81, deviationLabel: 'norm. abs. price dev.' },
  4: { haesselR2: 0.65, amplitude: 0.55, deviation: 1.06, deviationLabel: 'norm. abs. price dev.' },
};

/**
 * DLM (2005), Table 2 — permutation-test p-values. Round-1 vs round-4 differences are
 * significant (the bubble shrinks); round-3 vs round-4 are not (R3 ≈ R4); and the two
 * replacement treatments are statistically indistinguishable (R4-2/3 ≈ R4-1/3).
 */
export const DLM_SIGNIFICANCE = {
  R1_eq_R4: { haesselR2: '0.004***', amplitude: '0.003***', deviation: '0.032**' },
  R3_eq_R4: { haesselR2: '0.618', amplitude: '0.819', deviation: '0.061*' },
  R4two3_eq_R4one3: { haesselR2: '1.000', amplitude: '0.841', deviation: '0.421' },
} as const;

/**
 * m0nius reference — per-round mean absolute price deviation |P−FV| in cents. This is the
 * only per-round market-quality metric m0nius reports, and it is the honest apples-to-apples
 * faithfulness check against "Ours". Verified live 2026-06-05 (Session 1 read off the batch
 * table: 3.6 / 2.4 / 1.8 / 2.4; values below are the 10-session batch averages m0nius reports).
 */
export const M0NIUS_DEV: Record<1 | 2 | 3 | 4, number> = { 1: 3.65, 2: 2.49, 3: 1.72, 4: 2.28 };

/**
 * m0nius reference — pooled market-quality measures (over a full 4-round session, not per
 * round). Verified live 2026-06-05 from m0nius's "Market Quality" panel. Haessel R² uses
 * m0nius's displayed definition 1 − Σ(P̄−FV)²/Σ(P̄−P̄̄)²; amplitude is (max−min)(P̄−FV)/FV₁.
 * Pooled R² is high because pooling four declining FV staircases inflates the price variance.
 */
export const M0NIUS_POOLED = { haesselR2: 0.992, amplitude: 0.048 } as const;

/** m0nius round-4 at 67% replacement (the R4-1/3 minority-experienced treatment), mean |P−FV| ¢. */
export const M0NIUS_R4_ONE3_DEVIATION = 2.81;

// --- Faithfulness claim evaluation -------------------------------------------------------

export interface PerRound {
  haesselR2: number;
  amplitude: number;
  /** mean abs deviation |P - FV| for the round (our native, comparable to m0nius). */
  meanDev: number;
}

export interface ClaimResult {
  id: string;
  label: string;
  holds: boolean;
  detail: string;
}

/**
 * Evaluate the DLM conclusions against our per-round Plan I metrics (rounds 1..4).
 * Pure function — used by the proof panel and unit-tested.
 */
export function evaluateClaims(rounds: PerRound[]): ClaimResult[] {
  const [r1, r2, r3, r4] = rounds;
  const claims: ClaimResult[] = [];

  if (r1 && r2 && r3) {
    const decreasing = r1.meanDev > r2.meanDev && r2.meanDev > r3.meanDev;
    claims.push({
      id: 'decreasing',
      label: 'Point 1 — mispricing decreases with experience (R1 > R2 > R3)',
      holds: decreasing,
      detail: `mean |P-FV|: ${r1.meanDev.toFixed(2)} → ${r2.meanDev.toFixed(2)} → ${r3.meanDev.toFixed(2)}`,
    });
  }
  if (r1 && r3 && r4) {
    claims.push({
      id: 'r4-abated',
      label: 'Point 2 — round-4 bubble is abated, not a return (R4 ≪ R1)',
      holds: r4.meanDev < r1.meanDev,
      detail: `R4 mean |P-FV| = ${r4.meanDev.toFixed(2)} vs R1 = ${r1.meanDev.toFixed(2)}`,
    });
  }
  if (r1 && r2 && r3 && r4) {
    // Faithfulness-to-target check: our per-round mispricing tracks the m0nius reference
    // (mean |P−FV| ¢). This is the honest replication claim — same mechanism, same numbers —
    // and replaces the earlier circular "R² > 0.9" tick (which only passed because the metric
    // was inflated). NOT a claim about matching the larger DLM human bubble magnitude.
    const ref = [M0NIUS_DEV[1], M0NIUS_DEV[2], M0NIUS_DEV[3], M0NIUS_DEV[4]];
    const mine = [r1.meanDev, r2.meanDev, r3.meanDev, r4.meanDev];
    const mad = mine.reduce((s, v, i) => s + Math.abs(v - ref[i]), 0) / 4;
    claims.push({
      id: 'tracks-m0nius',
      label: 'Matches the m0nius reference per-round mispricing (mean |P-FV|)',
      holds: mad < 1.5,
      detail: `mean abs diff vs m0nius {3.65,2.49,1.72,2.28} = ${mad.toFixed(2)}¢`,
    });
  }
  return claims;
}
