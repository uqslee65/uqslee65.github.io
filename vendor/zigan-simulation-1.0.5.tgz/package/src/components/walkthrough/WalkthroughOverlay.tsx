import { useSimulator } from '../simulator/SimulatorProvider';
import { useWalkthrough } from './WalkthroughProvider';
import { Spotlight } from './Spotlight';
import { ComparisonPanel, CrossPlanPanel } from './ComparisonPanel';

const btn: React.CSSProperties = {
  padding: '0.4rem 0.8rem', borderRadius: 6, border: '1px solid var(--border)',
  background: 'var(--bg-card)', color: 'var(--fg)', fontSize: '0.8rem', cursor: 'pointer',
};
const btnPrimary: React.CSSProperties = { ...btn, background: 'var(--accent)', color: '#fff', borderColor: 'var(--accent)' };
const btnDisabled: React.CSSProperties = { opacity: 0.45, cursor: 'not-allowed' };

export function WalkthroughOverlay() {
  const wt = useWalkthrough();
  const sim = useSimulator();
  if (!wt.active) return null;

  const { stage, stageIndex, total } = wt;
  const isLast = stageIndex === total - 1;

  return (
    <>
      <Spotlight selector={stage.spotlight} />
      <aside
        data-testid="walkthrough-card"
        style={{
          position: 'fixed', top: 0, right: 0, bottom: 0, width: 'min(460px, 92vw)',
          background: 'var(--bg-card)', borderLeft: '1px solid var(--border)',
          boxShadow: '-8px 0 30px rgba(0,0,0,0.18)', zIndex: 1500,
          display: 'flex', flexDirection: 'column', padding: '1rem 1.1rem',
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ fontSize: '0.66rem', fontWeight: 800, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{stage.tag}</span>
            <span style={{ fontSize: '0.7rem', color: 'var(--fg-3)' }}>Stage {stageIndex + 1} / {total}</span>
          </div>
          <button onClick={wt.exit} aria-label="Exit walkthrough" style={{ ...btn, padding: '0.2rem 0.5rem' }}>✕</button>
        </div>

        {/* Progress dots */}
        <div style={{ display: 'flex', gap: 4, marginBottom: '0.75rem' }}>
          {Array.from({ length: total }, (_, i) => (
            <div key={i} style={{ flex: 1, height: 3, borderRadius: 2, background: i <= stageIndex ? 'var(--accent)' : 'var(--border)' }} />
          ))}
        </div>

        {/* Body (scrollable) */}
        <div style={{ flex: 1, overflowY: 'auto', paddingRight: 4 }}>
          <h2 style={{ fontSize: '1rem', fontWeight: 800, margin: '0 0 0.6rem' }}>{stage.title}</h2>
          <div style={{ fontSize: '0.82rem', color: 'var(--fg)' }}>{stage.body}</div>

          {/* LLM stage: key + live run trigger */}
          {stage.kind === 'run-llm' && (
            <div style={{ margin: '0.5rem 0 0.75rem', padding: '0.75rem', border: '1px solid var(--border)', borderRadius: 8, background: 'var(--stat-bg)' }}>
              <label style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--fg-3)', display: 'block', marginBottom: '0.3rem' }}>
                DeepSeek API key (required)
              </label>
              <p style={{ fontSize: '0.66rem', color: 'var(--fg-3)', margin: '0 0 0.4rem' }}>
                A full run (10 agents × 4 rounds × 20 periods) makes one live LLM call per agent
                per period — the 10 agents run concurrently, so a full run takes roughly{' '}
                <strong>2–3 min</strong> (and real token spend). The key is used in-browser only
                and never stored.
              </p>
              <input
                data-testid="wt-api-key"
                type="password"
                value={wt.apiKey}
                onChange={(e) => wt.setApiKey(e.target.value)}
                placeholder="sk-…"
                autoComplete="off"
                style={{ width: '100%', padding: '0.4rem 0.6rem', borderRadius: 6, border: '1px solid var(--border)', background: 'var(--bg-card)', color: 'var(--fg)', fontSize: '0.8rem' }}
              />
              <button
                data-testid="wt-run-llm"
                onClick={wt.runCurrentLLM}
                disabled={!wt.apiKey.trim() || sim.llmRunning || wt.busy}
                style={{ ...btnPrimary, marginTop: '0.5rem', ...(!wt.apiKey.trim() || sim.llmRunning || wt.busy ? btnDisabled : {}) }}
              >
                {sim.llmRunning || wt.busy ? 'Running live LLM…' : 'Run live simulation'}
              </button>
              {sim.llmProgress && (
                <p style={{ fontSize: '0.68rem', color: 'var(--fg-3)', margin: '0.4rem 0 0' }}>
                  {sim.llmProgress.status} — round {sim.llmProgress.round}, period {sim.llmProgress.period}
                </p>
              )}
              {sim.error && <p style={{ fontSize: '0.68rem', color: '#dc2626', margin: '0.4rem 0 0' }}>{sim.error}</p>}
            </div>
          )}

          {/* Proof panel */}
          {stage.proofFromStage && <ComparisonPanel ours={wt.outputs[stage.proofFromStage]} />}

          {/* Cross-plan */}
          {stage.comparePlans && (
            <CrossPlanPanel plans={stage.comparePlans.map((p) => ({ label: p.label, output: wt.outputs[p.stageId] }))} />
          )}
        </div>

        {/* Footer nav */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '0.75rem', paddingTop: '0.5rem', borderTop: '1px solid var(--border)' }}>
          <button data-testid="wt-prev" onClick={wt.prev} disabled={stageIndex === 0} style={{ ...btn, ...(stageIndex === 0 ? btnDisabled : {}) }}>← Back</button>
          <span style={{ fontSize: '0.68rem', color: 'var(--fg-3)', flex: 1, textAlign: 'center' }}>
            {!wt.canAdvance && wt.blockReason}
          </span>
          {isLast ? (
            <button data-testid="wt-finish" onClick={wt.exit} style={btnPrimary}>Finish ✓</button>
          ) : (
            <button data-testid="wt-next" onClick={wt.next} disabled={!wt.canAdvance} style={{ ...btnPrimary, ...(!wt.canAdvance ? btnDisabled : {}) }}>Next →</button>
          )}
        </div>
      </aside>
    </>
  );
}

export function WalkthroughLaunchButton() {
  const wt = useWalkthrough();
  if (wt.active) return null;
  return (
    <button
      data-testid="wt-launch"
      onClick={wt.start}
      style={{
        padding: '0.4rem 0.8rem', borderRadius: 6, border: '1px solid var(--accent)',
        background: 'color-mix(in srgb, var(--accent) 10%, var(--bg-card))', color: 'var(--accent)',
        fontSize: '0.8rem', fontWeight: 700, cursor: 'pointer',
      }}
    >
      ✦ Guided walkthrough
    </button>
  );
}
