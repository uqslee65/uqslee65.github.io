import type { ReactNode } from 'react';
import type { PlanType, SimConfig } from '../../lib/sim/types';
import { Tex } from './Tex';

export interface Stage {
  id: string;
  title: string;
  /** Short tag shown in the progress header. */
  tag: string;
  body: ReactNode;
  kind: 'info' | 'run-plan-i' | 'run-llm';
  plan?: PlanType;
  config?: Partial<SimConfig>;
  /** CSS selector of the element to glow/spotlight while this stage is shown. */
  spotlight?: string;
  /** Render the 3-column proof panel using a prior stage's cached output. */
  proofFromStage?: string;
  /** Cross-plan comparison: stage ids whose cached outputs to tabulate. */
  comparePlans?: { stageId: string; label: string }[];
}

const P = ({ children }: { children: ReactNode }) => (
  <p style={{ margin: '0 0 0.6rem', lineHeight: 1.6 }}>{children}</p>
);

export const STAGES: Stage[] = [
  {
    id: 'intro',
    title: 'Bubbles and Experience: an experiment',
    tag: 'Intro',
    kind: 'info',
    body: (
      <>
        <P>
          In the laboratory asset markets of Smith, Suchanek &amp; Williams (1988), inexperienced
          traders reliably produce <strong>price bubbles</strong>: prices rise far above the
          asset's fundamental value, then crash near expiry — even though every trader knows the
          fundamental exactly.
        </P>
        <P>
          Dufwenberg, Lindqvist &amp; Moore (<em>AER</em> 2005, "DLM") ask the question this
          walkthrough is about: <strong>does experience kill the bubble, and does a minority of
          experienced traders suffice?</strong> We reproduce their design with algorithmic
          (Plan&nbsp;I) and LLM (Plan&nbsp;II/III) agents, and reconcile our numbers against both
          the original paper and the m0nius reference implementation at each step.
        </P>
        <P>
          Use the <strong>← / →</strong> arrows to move between stages; you can always go back to
          re-read a result. The tour drives the simulator for you.
        </P>
      </>
    ),
  },
  {
    id: 'fv',
    title: 'The asset and its fundamental value',
    tag: 'Fundamentals',
    kind: 'info',
    body: (
      <>
        <P>
          A single asset lives for <Tex>{'T'}</Tex> periods. Each period it pays a random dividend
          (DLM: <Tex>{'\\{0, 20\\}'}</Tex>¢ with equal probability; we use the finer scaled
          schedule <Tex>{'\\{0, 10\\}'}</Tex>¢, <Tex>{'\\mathbb{E}[d]=5'}</Tex>¢ over{' '}
          <Tex>{'T=20'}</Tex>). By backward induction the risk-neutral fundamental value with{' '}
          <Tex>{'k=T-t+1'}</Tex> periods of dividends remaining is
        </P>
        <Tex block>{'FV_t = \\mathbb{E}[d]\\,(T-t+1)'}</Tex>
        <P>
          a declining staircase from <Tex>{'FV_1=100'}</Tex>¢ to <Tex>{'FV_{20}=5'}</Tex>¢. This
          is exogenous and common knowledge — so <em>any</em> persistent gap between price and{' '}
          <Tex>{'FV_t'}</Tex> is mispricing, not news. The amber dashed line on the chart is{' '}
          <Tex>{'FV_t'}</Tex>.
        </P>
      </>
    ),
  },
  {
    id: 'beliefs',
    title: 'How an agent forms a price belief',
    tag: 'Agents',
    kind: 'info',
    body: (
      <>
        <P>Each agent blends a private prior with the market consensus:</P>
        <Tex block>{'V^{\\text{post}}_{i,t} = \\omega_i\\,V^{\\text{prior}}_{i,t} + (1-\\omega_i)\\,\\bar m_t'}</Tex>
        <P>
          where <Tex>{'\\bar m_t'}</Tex> is the (confidence-weighted) cross-sectional mean belief,
          and the prior mixes the model fundamental with a behavioural heuristic,
        </P>
        <Tex block>{'V^{\\text{prior}}_{i,t} = \\big[\\alpha_i\\,\\widetilde{FV}_t + (1-\\alpha_i)\\,H_{i,t}\\big](1+b_i)(1+u)'}</Tex>
        <P>
          Experience moves three dials over rounds played <Tex>{'k'}</Tex>:{' '}
          <Tex>{'\\alpha_i=\\min(1,\\alpha_0+\\gamma_\\alpha k)'}</Tex> (anchor to fundamentals),{' '}
          <Tex>{'\\sigma_i=\\sigma_0 e^{-\\gamma_\\sigma k}'}</Tex> (sharper beliefs), and the
          self-weight <Tex>{'\\omega_i=\\omega_0+\\delta_\\omega\\min(k_{\\max},k)'}</Tex>. The
          novice bias <Tex>{'b_i'}</Tex> decays with experience. Agents act by maximising expected
          CRRA utility over <Tex>{'\\{\\text{hold, buy@ask, sell@bid, bid, ask}\\}'}</Tex>.
        </P>
        <P>
          <strong>Intuition.</strong> Novices lean on the herd and a biased prior → they chase and
          overshoot. Veterans anchor to <Tex>{'FV_t'}</Tex> and trust the crowd less → the bubble
          shrinks. This single mechanism produces all four DLM conclusions.
        </P>
      </>
    ),
  },
  {
    id: 'rounds',
    title: 'Four rounds and the experience design',
    tag: 'Design',
    kind: 'info',
    body: (
      <>
        <P>
          A session is <strong>four consecutive markets</strong> (rounds) for the asset. Rounds
          1–3 keep the <em>same</em> traders, who accumulate experience. In round&nbsp;4 some
          experienced traders are removed and replaced by newcomers — two treatments:
        </P>
        <P>
          <strong>R4-⅔</strong>: ⅔ stay experienced (replace ⅓). <strong>R4-⅓</strong>: only ⅓
          stay experienced (replace ⅔ — a <em>minority</em> of experienced traders). DLM's sharp
          question: does a minority of experienced traders still prevent the bubble?
        </P>
      </>
    ),
  },
  {
    id: 'measures',
    title: 'How we measure a bubble',
    tag: 'Measures',
    kind: 'info',
    body: (
      <>
        <P>Four measures, each comparing per-period mean price <Tex>{'\\bar P_t'}</Tex> to <Tex>{'FV_t'}</Tex>:</P>
        <Tex block>{'\\text{Haessel } R^2 = 1 - \\frac{\\sum_t(\\bar P_t-FV_t)^2}{\\sum_t(\\bar P_t-\\overline{\\bar P})^2}'}</Tex>
        <P>
          <strong>Haessel R²</strong> → 1 as prices track fundamentals (SST is the variance of the
          observed prices — the m0nius / Haessel 1978 definition). <strong>Amplitude</strong>{' '}
          <Tex>{'=\\big(\\max_t-\\min_t\\big)(\\bar P_t-FV_t)/FV_1'}</Tex> is the peak-to-trough
          mispricing. The honest reconciliation that follows compares the metric each source
          actually reports: <strong>mean <Tex>{'|P-FV|'}</Tex></strong> against the m0nius reference
          (per round), and <strong>amplitude</strong> against the DLM human market.
        </P>
      </>
    ),
  },
  {
    id: 'plan-i-run',
    title: 'Plan I — algorithmic agents, run a session',
    tag: 'Plan I',
    kind: 'run-plan-i',
    plan: 'plan-i',
    config: { treatment: 'R4-2/3' },
    spotlight: '[data-testid="price-chart"]',
    body: (
      <>
        <P>
          <strong>Plan I</strong> uses the deterministic belief rule above — no LLM. We've started
          a seeded session (treatment R4-⅔). Watch the highlighted price chart: prices excurse
          above <Tex>{'FV_t'}</Tex> early in round&nbsp;1, then track it more tightly each round as
          the agents gain experience.
        </P>
        <P>This run is deterministic (fixed seed), so the numbers on the next screen are reproducible.</P>
      </>
    ),
  },
  {
    id: 'plan-i-proof',
    title: 'Plan I — how does it reconcile?',
    tag: 'Reconcile',
    kind: 'info',
    proofFromStage: 'plan-i-run',
    body: (
      <>
        <P>
          An honest, two-way reconciliation. <strong>Top:</strong> our per-round mean{' '}
          <Tex>{'|P-FV|'}</Tex> against the <strong>m0nius</strong> reference — the implementation
          we replicate (same belief model + config). <strong>Bottom:</strong> amplitude against the{' '}
          <strong>DLM (2005)</strong> human market.
        </P>
        <P>
          The claims below are evaluated live. Our run reproduces the experience signature —
          mispricing <strong>decreases R1 → R3</strong> and round&nbsp;4 is <strong>abated, not a
          fresh bubble</strong> — and tracks the m0nius numbers. But note the bottom table: the
          human market bubbled <strong>~8× larger</strong>. Like m0nius, this is a fundamental-
          tracking model; it captures the <em>direction</em> of the experience effect, not the full
          human bubble <em>magnitude</em> (which needs speculative-resale dynamics this model omits).
        </P>
      </>
    ),
  },
  {
    id: 'plan-i-r4one3',
    title: 'Plan I — the minority-experienced treatment (Point 2)',
    tag: 'R4-⅓',
    kind: 'run-plan-i',
    plan: 'plan-i',
    config: { treatment: 'R4-1/3' },
    spotlight: '[data-testid="price-chart"]',
    proofFromStage: 'plan-i-r4one3',
    body: (
      <>
        <P>
          Now the hard case: round&nbsp;4 with only <strong>⅓ experienced</strong> traders (we
          re-ran with treatment R4-⅓). DLM's headline result is that even this <em>minority</em>
          of experienced traders prevents a large bubble — the two treatments are statistically
          indistinguishable (<Tex>{'p\\approx 0.42'}</Tex>).
        </P>
        <P>
          Check the round-4 row below: our R4 mispricing stays well under the round-1 bubble. m0nius
          at the same 67%-replacement setting reports mean <Tex>{'|P-FV|\\approx 2.8'}</Tex>¢ — in
          band with ours.
        </P>
      </>
    ),
  },
  {
    id: 'plan-ii',
    title: 'Plan II — LLM agents with the utility function',
    tag: 'Plan II',
    kind: 'run-llm',
    plan: 'plan-ii',
    spotlight: '[data-testid="price-chart"]',
    proofFromStage: 'plan-ii',
    body: (
      <>
        <P>
          <strong>Plan II</strong> replaces the algorithmic rule with a live LLM call per agent per
          period (DeepSeek <code>deepseek-v4-flash</code>). The prompt hands the agent its{' '}
          <strong>closed-form CRRA utility</strong>
          <Tex block>{'U(w;\\rho_i)=\\dfrac{w^{1-\\rho_i}}{1-\\rho_i}'}</Tex>
          with its sampled risk parameter <Tex>{'\\rho_i'}</Tex>, and asks for an action.
        </P>
        <P>
          This stage <strong>requires a real API key</strong> — the walkthrough cannot continue on
          fabricated output. Enter your DeepSeek key and run the live simulation; the progress bar
          tracks the per-period LLM calls.
        </P>
      </>
    ),
  },
  {
    id: 'plan-iii',
    title: 'Plan III — LLM agents with only a risk label',
    tag: 'Plan III',
    kind: 'run-llm',
    plan: 'plan-iii',
    spotlight: '[data-testid="price-chart"]',
    proofFromStage: 'plan-iii',
    body: (
      <>
        <P>
          <strong>Plan III</strong> is identical wiring to Plan&nbsp;II, but the prompt omits the
          utility formula and only <em>names</em> the risk preference ("risk-loving / neutral /
          averse"). This isolates whether handing an LLM the explicit functional form changes how
          it prices risk. Run it live and compare the trajectory to Plan&nbsp;II.
        </P>
      </>
    ),
  },
  {
    id: 'cross-plan',
    title: 'Cross-plan comparison',
    tag: 'Compare',
    kind: 'info',
    comparePlans: [
      { stageId: 'plan-i-run', label: 'Plan I (algorithmic)' },
      { stageId: 'plan-ii', label: 'Plan II (LLM + utility)' },
      { stageId: 'plan-iii', label: 'Plan III (LLM + label)' },
    ],
    body: (
      <>
        <P>
          Round-1 vs round-3 mispricing across the three agent models. Plan&nbsp;I (algorithmic)
          reproduces the DLM staircase most cleanly; the LLM plans show whether — and how — language
          models inherit the same experience effect. This is the comparison a reviewer wants: same
          market substrate, three decision rules, one human-experiment target.
        </P>
      </>
    ),
  },
  {
    id: 'conclusions',
    title: 'The four conclusions, reproduced',
    tag: 'Conclusions',
    kind: 'info',
    body: (
      <>
        <P><strong>1.</strong> A positive bubble that <strong>decreases as players gain experience</strong> (rounds 1 → 3).</P>
        <P><strong>2.</strong> A <strong>minority experienced + majority inexperienced</strong> population does <strong>not</strong> generate a large bubble (R4-⅓ ≈ R4-⅔ ≪ R1).</P>
        <P><strong>3.</strong> Mispricing <strong>depends on the asset type</strong> (try the other asset classes outside the walkthrough).</P>
        <P><strong>4.</strong> Experience <strong>does not transfer across uncorrelated assets</strong> (swap the asset at the replacement round).</P>
        <P>
          Each <em>qualitative</em> conclusion is reconciled live against m0nius and DLM (2005) on
          the screens above — these directions reproduce faithfully. The one honest caveat: this
          model (like the m0nius reference) tracks fundamentals more tightly than the human market,
          so it reproduces the <em>direction</em> of each effect rather than the full bubble{' '}
          <em>magnitude</em>.
        </P>
      </>
    ),
  },
];
