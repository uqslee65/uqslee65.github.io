import { DLM_TABLE2, M0NIUS_DEV, M0NIUS_POOLED, evaluateClaims, type PerRound } from './referenceData';

const cell: React.CSSProperties = { padding: '0.25rem 0.5rem', textAlign: 'right', fontVariantNumeric: 'tabular-nums' };
const head: React.CSSProperties = { ...cell, fontWeight: 700, color: 'var(--fg-3)', fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.04em' };

function num(n: number | undefined, d = 2) { return n === undefined ? '—' : n.toFixed(d); }

export function ComparisonPanel({ ours }: { ours: PerRound[] | undefined }) {
  const claims = ours ? evaluateClaims(ours) : [];
  const oursR1Amp = ours?.[0]?.amplitude;
  return (
    <div data-testid="comparison-panel" style={{ marginTop: '0.5rem' }}>
      {/* Faithfulness to the chosen target (m0nius): per-round mean |P−FV| — both real numbers. */}
      <Measure2
        title="Mean |P−FV| (¢) — vs m0nius reference"
        leftLabel="m0nius"
        dp={2}
        rows={[1, 2, 3, 4].map((r) => ({ round: r, left: M0NIUS_DEV[r as 1], ours: ours?.[r - 1]?.meanDev }))}
      />
      {/* Magnitude vs the DLM human experiment — shown honestly, with the gap called out below. */}
      <Measure2
        title="Price amplitude (÷FV₁) — vs DLM (2005) human market"
        leftLabel="DLM ’05"
        dp={3}
        rows={[1, 2, 3, 4].map((r) => ({ round: r, left: DLM_TABLE2[r as 1].amplitude, ours: ours?.[r - 1]?.amplitude }))}
      />
      <p style={{ fontSize: '0.66rem', color: 'var(--fg-3)', margin: '0 0 0.6rem', lineHeight: 1.45 }}>
        <strong>Honest reconciliation.</strong> Top table: our per-round mispricing tracks the{' '}
        <strong>m0nius</strong> reference (same belief model + config) — that is the replication
        target. Bottom table: the <strong>DLM</strong> human market bubbled far larger (R1 amplitude
        0.81 vs ours ≈ {num(oursR1Amp, 2)}). Like m0nius (pooled Haessel R² {M0NIUS_POOLED.haesselR2},
        amplitude {M0NIUS_POOLED.amplitude}), this model reproduces the experience-driven{' '}
        <em>direction</em>, not the human bubble <em>magnitude</em>. Haessel R² uses the m0nius
        definition 1 − Σ(P̄−FV)²/Σ(P̄−P̄̄)².
      </p>

      <div data-testid="claim-list">
        {claims.map((c) => (
          <div key={c.id} style={{ display: 'flex', gap: '0.5rem', alignItems: 'baseline', margin: '0.25rem 0', fontSize: '0.74rem' }}>
            <span style={{ color: c.holds ? '#16a34a' : '#dc2626', fontWeight: 800 }}>{c.holds ? '✓' : '✗'}</span>
            <span>
              <strong>{c.label}</strong>
              <span style={{ color: 'var(--fg-3)' }}> — {c.detail}</span>
            </span>
          </div>
        ))}
        {!ours && <p style={{ fontSize: '0.74rem', color: 'var(--fg-3)' }}>Running…</p>}
      </div>
    </div>
  );
}

interface Row2 { round: number; left: number; ours: number | undefined; }

function Measure2({ title, leftLabel, rows, dp }: { title: string; leftLabel: string; rows: Row2[]; dp: number }) {
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem', marginBottom: '0.6rem' }}>
      <thead>
        <tr>
          <th style={{ ...head, textAlign: 'left' }}>{title}</th>
          <th style={head}>{leftLabel}</th>
          <th style={{ ...head, color: 'var(--accent)' }}>Ours</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.round} style={{ borderTop: '1px solid var(--border)' }}>
            <td style={{ ...cell, textAlign: 'left', fontWeight: 600 }}>R{r.round}</td>
            <td style={cell}>{num(r.left, dp)}</td>
            <td style={{ ...cell, color: 'var(--accent)', fontWeight: 700 }}>{num(r.ours, dp)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

/** Cross-plan: round-1 vs round-3 mean |P-FV| per plan. */
export function CrossPlanPanel({ plans }: { plans: { label: string; output: PerRound[] | undefined }[] }) {
  return (
    <table data-testid="cross-plan-panel" style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.72rem' }}>
      <thead>
        <tr>
          <th style={{ ...head, textAlign: 'left' }}>Plan</th>
          <th style={head}>R1 mean |P−FV|</th>
          <th style={head}>R3 mean |P−FV|</th>
          <th style={head}>R1 → R3</th>
        </tr>
      </thead>
      <tbody>
        {plans.map((p) => {
          const r1 = p.output?.[0]?.meanDev, r3 = p.output?.[2]?.meanDev;
          const down = r1 !== undefined && r3 !== undefined && r3 < r1;
          return (
            <tr key={p.label} style={{ borderTop: '1px solid var(--border)' }}>
              <td style={{ ...cell, textAlign: 'left', fontWeight: 600 }}>{p.label}</td>
              <td style={cell}>{num(r1)}</td>
              <td style={cell}>{num(r3)}</td>
              <td style={{ ...cell, color: down ? '#16a34a' : 'var(--fg-3)', fontWeight: 700 }}>
                {r1 === undefined ? '—' : down ? '↓ shrinks' : 'n/a'}
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
