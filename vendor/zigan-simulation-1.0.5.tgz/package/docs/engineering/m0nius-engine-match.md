# Reverse-engineering the m0nius engine: deriving the structural-bubble model

**Date:** 2026-06-05
**Status:** shipped (zigan-simulation 1.0.5)
**Goal:** make our Plan I (algorithmic) engine reproduce the m0nius reference
(`https://assets.m0nius.com/`) per-round mispricing **and** its near-deterministic,
low-variance behaviour — without access to m0nius's source.

---

## 1. The problem

The walkthrough reconciles our replication against the m0nius reference on per-round mean
absolute deviation `|P − FV|`. Two deviations were flagged:

1. **Level:** our R4 (mixed-experience round) and some rounds were off m0nius by up to ~0.9¢.
2. **Variance (the big one):** m0nius's per-session results are near-deterministic
   (sd ≈ 0.06–0.10¢ across sessions); ours swung wildly (sd ≈ 1.0–1.3¢, single sessions ranging
   ~1.3–6.8¢). A user comparing single runs saw a "very significant difference."

We could not obtain m0nius's source, so we reverse-engineered its mechanism by **probing the live
site across configurations** (it exposes every parameter) and matching the observed behaviour.

## 2. Probing m0nius (method)

Driven via Playwright. For each config we ran m0nius's batch (it logs per-round
mean `|P−FV|` per session in the `Rr_Ss` table) and read the numbers off its own UI.

Baseline (default Plan I, N=10, R=4, α0=1, σ0=5, ω0=0.6, …), 5 sessions:

| round | mean `|P−FV|` ¢ | session values | sd |
|---|---|---|---|
| R1 | 3.64 | 3.8 3.5 3.7 3.6 3.6 | 0.10 |
| R2 | 2.50 | 2.5 2.4 2.6 2.5 2.5 | 0.06 |
| R3 | 1.68 | 1.7 1.6 1.7 1.7 1.7 | 0.04 |
| R4 (R4-2/3) | 2.22 | 2.3 2.2 2.3 2.1 2.2 | 0.07 |
| R4 (R4-1/3) | 2.81 | — | — |

**Key probes (toggling m0nius's own knobs):**

- **bias OFF + noise OFF:** bubble persists — R1 3.2 / R2 2.1 / R3 1.2 / R4 1.8 — and is
  **identical across sessions** (deterministic). Trades collapse from ~1500 to ~28/round.
- **bias OFF + noise OFF + σ₀ = 0:** *still* 3.2 / 2.1 / 1.3. So σ₀ doesn't drive it either.

### Conclusion from probing

m0nius's bubble is **structural and deterministic** — it survives with every stochastic input
(behavioural bias, prior noise, perceived-FV dispersion σ₀) turned off, and it is reproducible
session-to-session. The stochastic terms only add **trading volume / order-flow heterogeneity**
(noise OFF drops trades 1500 → 28) and a small (~0.4¢) level bump. **m0nius's low variance is a
direct consequence of its bubble being structural rather than noise-manufactured.**

This was the decisive insight. Our engine did the opposite: its deterministic skeleton (bias +
noise off) was **flat — `0.39 / 0.40 / 0.39 / 0.32`, no bubble** — because beliefs equalled FV
exactly. We manufactured the entire bubble from a *random* behavioural bias term, so the thing
that made our bubble was the same thing that made our (20×-too-high) variance.

## 3. The mechanism we derived

A bubble that (a) is deterministic, (b) declines with experience, and (c) needs no behavioural
bias is the textbook **partial adjustment of price toward a moving fundamental**. In a market
that only partially adjusts each period, price lags the declining FV and sits above it; the lag
(= the bubble) shrinks as traders adjust faster with experience.

We model it in `Agent.priorValuation` (`engine.ts`):

```
alpha_i = min(1, alpha0 + gammaAlpha * k)            // adjustment speed; k = rounds of experience
V_prior = alpha_i * FV_t + (1 - alpha_i) * smoothed   // partial adjustment toward FV
smoothed = V_prior                                    // deterministic anchor carried to next period
```

- The anchor is the agent's own **previous deterministic smoothed value**, *not* the noisy traded
  price — anchoring to the traded price would re-introduce session variance (and feedback
  runaways). This is what keeps the bubble reproducible (low variance), matching m0nius.
- `smoothed` resets to `fv1` at each round start (`resetBelief`), so period 1 starts on FV and the
  lag accumulates only as FV falls within the round.
- Experience raises `alpha_i` → faster adjustment → smaller lag → the bubble shrinks R1 → R3.
- The explicit random behavioural bias (`makeAgent`) is **retired** (set to 0); the bubble is now
  structural. Prior noise (±3%) is kept only as order-flow heterogeneity for liquidity — it
  averages out of the per-period mean and does not drive the bubble.

### The replacement round (DLM Point 2)

With the structural mechanism, the mixed round abates **naturally** as a proportional blend of
experienced (low-lag) and novice (high-lag, reset `smoothed`) valuations:

- R4-2/3 (2/3 experienced) ≈ ⅔·veteran + ⅓·novice → sits well below R1, just above R3.
- R4-1/3 (1/3 experienced) ≈ ⅓·veteran + ⅔·novice → higher than R4-2/3, still below R1.

The previous code added an extra "veteran-fraction" suppression of novice self-weight plus an
ω-weighted peer mean. With the new mechanism that **over-abated** R4 (pushed it *below* R3 — the
opposite of m0nius, where R4 > R3), so both were removed in favour of a **plain cross-sectional
peer mean** `m̄_t`. Point 2 still holds because the proportional blend already abates.

### The no-trade fallback bug (dominant variance source)

The single largest cause of R4 variance was unrelated to beliefs: when a late period produced
**no trades**, the old code set the period price to `lastPrice * 0.95` (a 5%/period decay). As FV
kept falling (e.g. 40 → 5), this frozen, slowly-decaying price diverged from FV and manufactured
a spurious bubble — one seed reached `dev = 26¢` at period 20. Fixed by pricing a quiet market at
the **cross-sectional mean belief** (which partial-adjusts toward FV), so a quiet market is priced
near fundamentals. This collapsed R4-2/3 sd from ~1.5 to ~0.16.

## 4. Calibration

`alpha0` sets the round-1 adjustment speed (steady-state lag ≈ `(1−α)/α · ΔFV_per_period`, and
ΔFV ≈ 5¢/period here, so α₀ ≈ 0.6 → R1 ≈ 3.3–3.6¢); `gammaAlpha` sets how fast the lag decays with
experience. Swept against the m0nius targets:

**Chosen: `alpha0 = 0.60`, `gammaAlpha = 0.09`** (in `DEFAULT_EXPERIENCE`, `types.ts`).

| round | m0nius | ours (24-seed mean ± sd) |
|---|---|---|
| R1 | 3.64 | 3.39 ± 0.06 |
| R2 | 2.50 | 2.47 ± 0.11 |
| R3 | 1.68 | 1.78 ± 0.08 |
| R4 (R4-2/3) | 2.22 | 2.27 ± 0.14 |
| R4 (R4-1/3) | 2.81 | 2.99 ± 0.11 |

All rounds within ~0.25¢ of m0nius; per-round sd ≤ 0.14¢ (vs the old ~1.0–1.3¢), now comparable to
m0nius's ~0.06–0.10¢. R4 > R3 (correct direction); Point 2 holds (R4-2/3 and R4-1/3 both ≪ R1).
The walkthrough's `tracks-m0nius` check (mean abs diff vs m0nius) fell from 0.38¢ to ~0.09¢.

## 5. Validation

- `replication.test.ts` (the four DLM conclusions) — all pass. Point 3 ("mispricing depends on
  asset type") was updated: under a partial-adjustment lag, mispricing arises when the fundamental
  *moves*, so it is contrasted as **moving (declining/growth) vs flat (perpetual)** rather than
  declining-vs-growth (which are now symmetric in magnitude — a correct property of a linear lag).
- Full unit suite: 60/60.
- Walkthrough e2e + live Heroku drive: the reconciliation panel renders the matched numbers.

## 6. Limitations / honesty

- This is an **independent reproduction of m0nius's behaviour**, not its source. We matched the
  *mechanism class* (deterministic experience-modulated partial adjustment) and its outputs, not
  necessarily its exact equations.
- We still do **not** reproduce the original DLM (2005) **human** bubble *magnitude* (R1 amplitude
  ≈ 0.81 in the paper vs ≈ 0.05–0.10 here) — and neither does m0nius. Both reproduce the
  experience-driven *direction*, not the full Smith-Suchanek-Williams bubble amplitude, which
  would require a speculative-resale/greater-fool motive absent from both models. The walkthrough
  discloses this gap explicitly.
- `linear-growth` and `linear-declining` now yield symmetric-magnitude mispricing (opposite sign),
  a property of the linear lag; if a future asset-type study needs them to differ, the mechanism
  would need an asymmetry (e.g. a positive-only optimism term).
